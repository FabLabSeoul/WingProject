#pragma once

bool bma280Detect(sensor_t *acc);
