#pragma once

bool bmp280Detect(baro_t *baro);

