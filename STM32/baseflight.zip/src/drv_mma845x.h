#pragma once

bool mma8452Detect(sensor_t *acc);
