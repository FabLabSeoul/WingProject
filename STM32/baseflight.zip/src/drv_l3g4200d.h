#pragma once

bool l3g4200dDetect(sensor_t *gyro, uint16_t lpf);
